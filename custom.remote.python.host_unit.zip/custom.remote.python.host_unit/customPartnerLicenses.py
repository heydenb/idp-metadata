from ruxit.api.base_plugin import RemoteBasePlugin
from ruxit.api.data import PluginProperty
from ruxit.api.exceptions import AuthException, ConfigException
import requests
import json
import time
import datetime
import math
from math import ceil
import logging
import os
import ast
import boto3
from botocore.config import Config
from botocore.exceptions import ClientError
from boto3.exceptions import S3UploadFailedError
from enum import Enum
from typing import Dict, Optional
from urllib.parse import urlparse

logger = logging.getLogger(__name__)
workDir = os.path.dirname(__file__)
#results_dir = "/opt/dynatrace/remotepluginmodule/plugin_deployment/custom.remote.python.host_unit/HWM"
results_dir = os.path.join(workDir, "HWM")


# Numbers smaller than 1 cannot be different from these
host_unit_weighting = {
    "FULL_STACK": {1.6: 0.1, 4: 0.25, 8: 0.5, 16: 1.0, 32: 2.0, 48: 3.0, 64: 4.0},
    "PAAS": {1.6: 0.1, 4: 0.25, 8: 0.5, 16: 1.0, 32: 2.0, 48: 3.0, 64: 4.0},
    "INFRA_ONLY": {1.6: 0.03, 4: 0.075, 8: 0.15, 16: 0.3, 32: 0.6, 48: 0.9, 64: 1.0},
}

def _calculate_host_units(memory: float, monitoring_mode="FULL_STACK") -> float:
    """
    Calculates the host units number from the memory in bytes
    Based on the table at https://www.dynatrace.com/support/help/reference/monitoring-consumption-calculation/
    :param memory: Memory in bytes
    :param monitoring_mode: FULL_STACK, INFRA_ONLY or PAAS
    :return: The number of host units for this amount of memory
    """
    if memory <= 0:
        return 0

    mem_gigs = memory / (1024 ** 3)
    #logger.info('The memory gigs is "%f"' % mem_gigs)

    if mem_gigs > 64:
        if monitoring_mode == "FULL_STACK":
            return ceil(mem_gigs / 16)
        elif monitoring_mode == "PAAS":
            return ceil(mem_gigs / 16)
        return min(ceil(mem_gigs / 16) * 0.3, 1.0)
    else:
        for mem, hu in host_unit_weighting[monitoring_mode].items():
            if mem_gigs <= mem:
                return hu

class custom_Partner_Licenses(RemoteBasePlugin):

    def initialize(self, **kwargs):        
        #strip URL if required
        self.url = self.config.get("url", "http://127.0.0.1:8976")
        self.url = "https://" + urlparse(self.url).netloc
        self.msp_name = self.config.get("msp_name", "Internal")
        self.api_token = self.config.get("api_token", "admin")
        self.auth_header = {"Authorization": f"Api-Token {self.api_token}"}
        self.verify_certs = self.config.get("verify_certs", "True")
        self.proxy_address = self.config.get("proxy_address", "")
        if self.proxy_address.lower().startswith("http"):
            self.proxy_address = urlparse(self.proxy_address).netloc
        self.extension_iterations = 0
        self.previousHour = int(datetime.datetime.now().hour)
        self.previousS3 = False
        self.envlistone = {}
        self.envlisttwo = {}
        self.envlistthree = {}

        # Create the temp directory if it does not exist
        if not os.path.exists(results_dir):
            os.mkdir(results_dir)
        if not os.path.exists(os.path.join(results_dir, 'hwmLicenseAuditFile.txt')):
            with open(os.path.join(results_dir, 'hwmLicenseAuditFile.txt'), "w+"):
                pass

    def query(self, **kwargs):
        if self.should_getLicenseExport():
            #logger.info('The workDir was "%s"' % workDir)
            #logger.info('The results_dir2 was "%s"' % results_dir)
            #logger.info('The initial self.previousS3 was "%s"' % self.previousS3)
            #if not os.path.exists("/opt/dynatrace/remotepluginmodule/plugin_deployment/custom.remote.python.host_unit/S3Config.txt"):
            if not os.path.exists(os.path.join(workDir, 'S3Config.txt')):
                self.ConfigError = True
                logger.info('S3Config.txt file does not exist!')
            else:
                self.ConfigError = False
                #with open("/opt/dynatrace/remotepluginmodule/plugin_deployment/custom.remote.python.host_unit/S3Config.txt") as f:
                with open(os.path.join(workDir, 'S3Config.txt')) as f:
                    for l in f:
                        var, val = l.split("=")
                        globals()[var] = val.strip()
            try:
                msp_identifier
            except:
                logger.info('msp_identifier not found, please check S3Config.txt file')
                self.ConfigError = True
            try:
                aws_access_key_id
            except:
                logger.info('aws_access_key_id not found, please check S3Config.txt file')
                self.ConfigError = True
            try:
                aws_secret_access_key
            except:
                logger.info('aws_secret_access_key not found, please check S3Config.txt file')  
                self.ConfigError = True        
            try:
                bucket_name
            except:
                logger.info('bucket_name not found, please check S3Config.txt file')  
                self.ConfigError = True          
            #logger.info('The self.ConfigError was - "%s"' % self.ConfigError)  
            if self.ConfigError == False:                
                self.object_name = msp_identifier + "_hwmLicenseAuditFile.txt"
                self.s3FileName = os.path.join(results_dir, self.object_name)
                self.usedFile = self.object_name
                #S3 details
                if self.proxy_address != "":
                    self.s3 = boto3.client("s3",
                    aws_access_key_id=aws_access_key_id,
                    aws_secret_access_key=aws_secret_access_key,
                    config=Config(proxies={'https': self.proxy_address}))
                else:
                    self.s3 = boto3.client("s3",
                    aws_access_key_id=aws_access_key_id,
                    aws_secret_access_key=aws_secret_access_key)                   
                #Only download S3 file if previous run used S3 file otherwise revert to local
                if self.previousS3 == True:
                    #Download S3 file if available
                    try:
                        response = self.s3.download_file(bucket_name, self.object_name, self.s3FileName)
                    except ClientError as e:
                        logger.info('S3 Download error code "%s"' % e.response['Error']['Code'])
                        logger.info('S3 Download HTTP code "%s"' % e.response['ResponseMetadata']['HTTPStatusCode'])
                        logger.info('S3 Download error message "%s"' % e.response['Error']['Message'])
                        self.usedFile = "hwmLicenseAuditFile.txt"
                else:
                    self.usedFile = "hwmLicenseAuditFile.txt"
            else:
                logger.info('self.ConfigError is true, please check S3Config.txt file')
                self.usedFile = "hwmLicenseAuditFile.txt"
            
            #logger.info('The self.usedFile is "%s"' % self.usedFile)
            #logger.info('The self.previousS3 after S3 download was "%s"' % self.previousS3)

            not_found = True
            #Create array for current hour customers
            customerTotals = []
            #create array to read current HWMs from file
            highWaterMarks = []
            with open(os.path.join(results_dir, self.usedFile), 'r') as filehandle:
                for line in filehandle:
                    # remove linebreak which is the last character of the string
                    currentCustomer = line[:-1]
                    # add item to the list
                    highWaterMarks.append(ast.literal_eval(currentCustomer))

            group_name = self.msp_name + " Tenants"
            topology_group = self.topology_builder.create_group(group_name, group_name)
            cluster_url = self.url + "/cmc"
            topology_group.report_property(key="Cluster_URL", value=cluster_url)
            licenseExp = self.get_LicenseExport()
            customers = self.get_environments()
            if self.envlistone == {}:
                self.envlistone = customers
            if self.envlisttwo == {}:
                self.envlisttwo = customers
            if self.envlistthree == {}:
                self.envlistthree = customers
            port = 80
            totalHU = 0.0
            totalFSHU = 0.0
            totalPSHU = 0.0
            totalIMHU = 0.0
            totalHosts = 0
            totalDEM = 0.0
            totalDDU = 0.0
            totalFSHosts = 0
            totalPSHosts = 0
            totalIMHosts = 0
            totalCustHU = 0.0
            totalCustFSHU = 0.0
            totalCustPSHU = 0.0
            totalCustIMHU = 0.0
            totalCustHosts = 0
            totalCustFSHosts = 0
            totalCustPSHosts = 0
            totalCustIMHosts = 0
            totalCustDEM = 0.0
            totalCustDDU = 0.0
            latestHW = 0.0
            curHW = 0.0

            for licEnv in licenseExp:
                DEM = 0.0
                DDU = 0.0
                visits = 0.0
                mobile = 0.0
                sessionReplay = 0.0
                mobilesessionReplay = 0.0
                rumProperties = 0.0
                httpMonitor = 0.0
                clickpath = 0.0
                inthttpMonitor = 0.0
                intclickpath = 0.0
                exthttpMonitor = 0.0
                extclickpath = 0.0
                rum = 0.0
                envID = licEnv['environmentUuid']
                if envID in customers:
                    customerName = customers[envID]['name']
                    if any("DtLicenseGroup:" in s for s in customers[envID]['tags']):
                        for tag in customers[envID]['tags']:
                            if "DtLicenseGroup" in tag:
                                myTag = tag.split("DtLicenseGroup:",1)[1]
                    else:
                        myTag = "Unassigned"
                    if any("DtCountry:" in s for s in customers[envID]['tags']):
                        for tag in customers[envID]['tags']:
                            if "DtCountry" in tag:
                                country = tag.split("DtCountry:",1)[1]
                    else:
                        country = "Unassigned"
                    if any("DtPOC" in s for s in customers[envID]['tags']):
                        poc = "TRUE"
                    else:
                        poc = "FALSE"
                elif envID in self.envlistone:
                    customerName = self.envlistone[envID]['name']
                    if any("DtLicenseGroup:" in s for s in self.envlistone[envID]['tags']):
                        for tag in self.envlistone[envID]['tags']:
                            if "DtLicenseGroup" in tag:
                                myTag = tag.split("DtLicenseGroup:",1)[1]
                    else:
                        myTag = "Unassigned"
                    if any("DtCountry:" in s for s in self.envlistone[envID]['tags']):
                        for tag in self.envlistone[envID]['tags']:
                            if "DtCountry" in tag:
                                country = tag.split("DtCountry:",1)[1]
                    else:
                        country = "Unassigned"
                    if any("DtPOC" in s for s in self.envlistone[envID]['tags']):
                        poc = "TRUE"
                    else:
                        poc = "FALSE"
                elif envID in self.envlisttwo:
                    customerName = self.envlisttwo[envID]['name']
                    if any("DtLicenseGroup:" in s for s in self.envlisttwo[envID]['tags']):
                        for tag in self.envlisttwo[envID]['tags']:
                            if "DtLicenseGroup" in tag:
                                myTag = tag.split("DtLicenseGroup:",1)[1]
                    else:
                        myTag = "Unassigned"
                    if any("DtCountry:" in s for s in self.envlisttwo[envID]['tags']):
                        for tag in self.envlisttwo[envID]['tags']:
                            if "DtCountry" in tag:
                                country = tag.split("DtCountry:",1)[1]
                    else:
                        country = "Unassigned"
                    if any("DtPOC" in s for s in self.envlisttwo[envID]['tags']):
                        poc = "TRUE"
                    else:
                        poc = "FALSE" 
                elif envID in self.envlistthree:
                    customerName = self.envlistthree[envID]['name']
                    if any("DtLicenseGroup:" in s for s in self.envlistthree[envID]['tags']):
                        for tag in self.envlistthree[envID]['tags']:
                            if "DtLicenseGroup" in tag:
                                myTag = tag.split("DtLicenseGroup:",1)[1]
                    else:
                        myTag = "Unassigned"
                    if any("DtCountry:" in s for s in self.envlistthree[envID]['tags']):
                        for tag in self.envlistthree[envID]['tags']:
                            if "DtCountry" in tag:
                                country = tag.split("DtCountry:",1)[1]
                    else:
                        country = "Unassigned"
                    if any("DtPOC" in s for s in self.envlistthree[envID]['tags']):
                        poc = "TRUE"
                    else:
                        poc = "FALSE" 
                else:
                    customerName = envID
                    myTag = "Unassigned"
                    country = "Unassigned"
                    poc = "FALSE" 
                env_url = self.url + "/e/" + envID
                topology_device = topology_group.create_device(customerName, customerName)
                totalEnvHU, totalEnvFSHU, totalEnvPSHU, totalEnvIMHU, totalEnvHosts, totalEnvFSHosts, totalEnvPSHosts, totalEnvIMHosts, state = self.get_environment_hosts(envID, licEnv['hostUsages'])
                if customerName != "DTLicenseExt" and poc != "TRUE":
                    totalHosts = totalHosts + totalEnvHosts
                    totalFSHosts = totalFSHosts + totalEnvFSHosts
                    totalPSHosts = totalPSHosts + totalEnvPSHosts            
                    totalIMHosts = totalIMHosts + totalEnvIMHosts
                    totalHU = totalHU + totalEnvHU
                    totalFSHU = totalFSHU + totalEnvFSHU
                    totalPSHU = totalPSHU + totalEnvPSHU
                    totalIMHU = totalIMHU + totalEnvIMHU
                topology_device.state_metric("mode.state_10", state)
                topology_device.absolute("licenses.total_tenant_num_hosts", totalEnvHosts)
                topology_device.absolute("licenses.total_tenant_num_FS_hosts", totalEnvFSHosts)
                topology_device.absolute("licenses.total_tenant_num_PS_hosts", totalEnvPSHosts)
                topology_device.absolute("licenses.total_tenant_num_IM_hosts", totalEnvIMHosts)            
                topology_device.report_property(key="Environment_URL", value=env_url)
                topology_device.report_property(key="Country", value=country)
                topology_device.report_property(key="POC", value=poc)
                topology_device.absolute("licenses.total_tenant_host_units", totalEnvHU)
                topology_device.absolute("licenses.total_tenant_FS_host_units", totalEnvFSHU)
                topology_device.absolute("licenses.total_tenant_PS_host_units", totalEnvPSHU)
                topology_device.absolute("licenses.total_tenant_IM_host_units", totalEnvIMHU)            
                topology_device.add_endpoint("127.0.0.1", port)
                port += 1
                visits = int(licEnv['visits'])
                mobile = int(licEnv['mobileSessions'])
                sessionReplay = int(licEnv['sessionReplays'])
                mobilesessionReplay = int(licEnv['mobileSessionReplays'])
                if int(licEnv['totalRUMUserPropertiesUsed']) > 20:
                    rumProperties = int(licEnv['totalRUMUserPropertiesUsed'])
                for syn in licEnv['syntheticBillingUsage']:
                    if int(syn['monitorTypeId']) == 2:
                        httpMonitor = httpMonitor + int(syn['publicExecutions']) + int(syn['privateExecutions'])
                        inthttpMonitor = inthttpMonitor + int(syn['privateExecutions'])
                        exthttpMonitor = exthttpMonitor + int(syn['publicExecutions'])
                    else:
                        clickpath = clickpath + int(syn['publicExecutions']) + int(syn['privateExecutions'])
                        intclickpath = intclickpath + int(syn['privateExecutions'])
                        extclickpath = extclickpath + int(syn['publicExecutions'])
                DEM = ((visits + mobile) * 0.25) + ((sessionReplay + mobilesessionReplay) * 0.75) + (rumProperties * 0.01) + (httpMonitor * 0.1) + clickpath
                inthttpMonitor = inthttpMonitor * 0.1
                exthttpMonitor = exthttpMonitor * 0.1
                rum = ((visits + mobile) * 0.25) + (rumProperties * 0.01)
                if customerName != "DTLicenseExt" and poc != "TRUE":
                    totalDEM = totalDEM + DEM
                topology_device.absolute("licenses.total_tenant_dem_units", DEM)
                topology_device.absolute("licenses.total_tenant_int_httpmon", inthttpMonitor)
                topology_device.absolute("licenses.total_tenant_int_click", intclickpath)
                topology_device.absolute("licenses.total_tenant_ext_httpmon", exthttpMonitor)
                topology_device.absolute("licenses.total_tenant_ext_click", extclickpath)
                topology_device.absolute("licenses.total_tenant_rum", rum)
                for item in licEnv['davisDataUnits']:
                    DDU = DDU + float(item['total'])
                topology_device.absolute("licenses.total_tenant_ddus", DDU)
                if customerName != "DTLicenseExt" and poc != "TRUE":
                    totalDDU = totalDDU + DDU
                not_found = True
                if customerName != "DTLicenseExt" and poc != "TRUE":
                    for enduser in customerTotals:
                        not_found = True
                        if myTag == enduser['customers']:
                            not_found = False
                            totalCustHU = enduser['totalCustHU'] + totalEnvHU
                            totalCustFSHU = enduser['totalCustFSHU'] + totalEnvFSHU
                            totalCustPSHU = enduser['totalCustPSHU'] + totalEnvPSHU
                            totalCustIMHU = enduser['totalCustIMHU'] + totalEnvIMHU
                            totalCustHosts = enduser['totalCustHosts'] + totalEnvHosts
                            totalCustFSHosts = enduser['totalCustFSHosts'] + totalEnvFSHosts
                            totalCustPSHosts = enduser['totalCustPSHosts'] + totalEnvPSHosts
                            totalCustIMHosts = enduser['totalCustIMHosts'] + totalEnvIMHosts
                            totalCustDEM = enduser['totalCustDEM'] + DEM
                            totalCustDDU = enduser['totalCustDDU'] + DDU
                            enduser.update({'country':country, 'totalCustHU':totalCustHU, 'totalCustFSHU':totalCustFSHU, 'totalCustPSHU':totalCustPSHU, 'totalCustIMHU':totalCustIMHU, 'totalCustHosts':totalCustHosts, 'totalCustFSHosts':totalCustFSHosts, 'totalCustPSHosts':totalCustPSHosts, 'totalCustIMHosts':totalCustIMHosts, 'totalCustDEM':totalCustDEM, 'totalCustDDU':totalCustDDU})
                            break
                    if not_found:
                        customerTotals.append({'customers':myTag, 'country':country, 'totalCustHU':totalEnvHU, 'totalCustFSHU':totalEnvFSHU, 'totalCustPSHU':totalEnvPSHU, 'totalCustIMHU':totalEnvIMHU, 'totalCustHosts':totalEnvHosts, 'totalCustFSHosts':totalEnvFSHosts, 'totalCustPSHosts':totalEnvPSHosts, 'totalCustIMHosts':totalEnvIMHosts, 'totalCustDEM':DEM, 'totalCustDDU':DDU})
            group_name = self.msp_name + " License Total"
            topology_group = self.topology_builder.create_group(group_name, group_name)
            topology_group.report_property(key="Cluster_URL", value=cluster_url)
            topology_device = topology_group.create_device(self.msp_name + " License Total", self.msp_name + " License Total")
            topology_device.report_property(key="Cluster_URL", value=cluster_url)
            topology_device.absolute("licenses.total_license_hosts", totalHosts)
            topology_device.absolute("licenses.total_license_FS_hosts", totalFSHosts)
            topology_device.absolute("licenses.total_license_PS_hosts", totalPSHosts)
            topology_device.absolute("licenses.total_license_IM_hosts", totalIMHosts)
            topology_device.absolute("licenses.total_license_host_units", totalHU)
            topology_device.absolute("licenses.total_license_FS_host_units", totalFSHU)
            topology_device.absolute("licenses.total_license_PS_host_units", totalPSHU)
            topology_device.absolute("licenses.total_license_IM_host_units", totalIMHU)
            topology_device.absolute("licenses.total_license_dem_units", totalDEM)
            topology_device.absolute("licenses.total_license_ddus", totalDDU)                    
            topology_device.add_endpoint("127.0.0.1", port)
            group_name = self.msp_name + " End-Clients"
            topology_group = self.topology_builder.create_group(group_name, group_name)
            topology_group.report_property(key="Cluster_URL", value=cluster_url)
            #merge current hour customer HWM to file data before looping through and posting metrics to DT
            for x in customerTotals:
                topology_device = topology_group.create_device(x['customers'], x['customers'])
                topology_device.report_property(key="Cluster_URL", value=cluster_url)
                topology_device.report_property(key="Country", value=x['country'])
                topology_device.absolute("licenses.total_customer_hosts", x['totalCustHosts'])
                topology_device.absolute("licenses.total_customer_FS_hosts", x['totalCustFSHosts'])
                topology_device.absolute("licenses.total_customer_PS_hosts", x['totalCustPSHosts'])
                topology_device.absolute("licenses.total_customer_IM_hosts", x['totalCustIMHosts'])
                topology_device.absolute("licenses.total_customer_host_units", x['totalCustHU'])
                topology_device.absolute("licenses.total_customer_FS_host_units", x['totalCustFSHU'])
                topology_device.absolute("licenses.total_customer_PS_host_units", x['totalCustPSHU'])
                topology_device.absolute("licenses.total_customer_IM_host_units", x['totalCustIMHU'])
                topology_device.absolute("licenses.total_customer_dem_units", x['totalCustDEM'])
                topology_device.absolute("licenses.total_customer_ddus", x['totalCustDDU'])                    
                topology_device.add_endpoint("127.0.0.1", port)
                customerName = x['customers']
                not_found = True
                for customerGrouping in highWaterMarks:
                    not_found = True
                    latestHW = float(x['totalCustHU'])
                    if customerName == customerGrouping['customers']:
                        not_found = False
                        curHW = float(customerGrouping['hostUnitHW'])
                        if latestHW > curHW:
                            customerGrouping.update({'customers':customerName, 'hostUnitHW':latestHW})
                            #topology_device.absolute("licenses.total_customer_HWM", latestHW)
                        #else:
                            #topology_device.absolute("licenses.total_customer_HWM", curHW)
                        break
                if not_found:
                    highWaterMarks.append({'customers':customerName, 'hostUnitHW':latestHW})
                    #topology_device.absolute("licenses.total_customer_HWM", x['totalCustHU'])    
            #Loop through customer HWM posting metrics to DT
            group_name = self.msp_name + " Customer HWM"
            topology_group = self.topology_builder.create_group(group_name, group_name)
            topology_group.report_property(key="Cluster_URL", value=cluster_url)
            for customerGroup in highWaterMarks:
                topology_device = topology_group.create_device(customerGroup['customers'], customerGroup['customers'])
                topology_device.absolute("licenses.total_customer_HWM", customerGroup['hostUnitHW'])
            #Set if values came from local or S3
            if self.usedFile == "hwmLicenseAuditFile.txt":
                selectedFile = 1
            else:
                selectedFile = 0
            topology_device = topology_group.create_device("File Type Indicator", "File Type Indicator")
            topology_device.absolute("licenses.total_customer_HWM", selectedFile)    
            self.envlistthree = self.envlisttwo
            self.envlisttwo = self.envlistone
            self.envlistone = customers
            with open(os.path.join(results_dir, 'hwmLicenseAuditFile.txt'), 'w+') as filehandle:
                for listitem in highWaterMarks:
                    filehandle.write('%s\n' % listitem)
            #write file to S3
            if self.ConfigError == False:
                with open(os.path.join(results_dir, self.object_name), 'w+') as filehandle:
                    for listitem in highWaterMarks:
                        filehandle.write('%s\n' % listitem)
                try:
                    response = self.s3.upload_file(self.s3FileName, bucket_name, self.object_name)
                except S3UploadFailedError as e:
                    logger.info('S3 Upload error - S3UploadFailedError')
                    self.previousS3 = False
                except ClientError as e:
                    logger.info('S3 Upload error code "%s"' % e.response['Error']['Code'])
                    logger.info('S3 Upload HTTP code "%s"' % e.response['ResponseMetadata']['HTTPStatusCode'])
                    logger.info('S3 Upload error message "%s"' % e.response['Error']['Message'])
                    self.previousS3 = False
                except:
                    self.previousS3 = False
                    logger.info('Unknown S3 Upload error')
                else:
                    self.previousS3 = True
            else:
                self.previousS3 = False
            #logger.info('The self.previousS3 after S3 upload was "%s"' % self.previousS3)


    # Get the host units per environment
    def get_environment_hosts(self, envID, hostUsages):
        totalEnvHosts = int(len(hostUsages))
        totalEnvFSHosts = 0
        totalEnvPSHosts = 0
        totalEnvIMHosts = 0
        totalEnvHU = 0.0
        totalEnvFSHU = 0.0
        totalEnvPSHU = 0.0
        totalEnvIMHU = 0.0
        for host in hostUsages:
            if not host['paas'] and not host['infrastructureOnly']:
                # Full-stack baby
                totalEnvFSHosts = totalEnvFSHosts + 1
                host_full_stack_units = _calculate_host_units(int(host['hostMemoryBytes']))
                totalEnvFSHU = totalEnvFSHU + host_full_stack_units
                totalEnvHU = totalEnvHU + host_full_stack_units
            elif host['paas']:
                # PaaS
                totalEnvPSHosts = totalEnvPSHosts + 1
                if int(host['passMemoryLimit']) == 0:
                     host_paas_units = _calculate_host_units(int(host['hostMemoryBytes']), monitoring_mode="PAAS")
                else:
                    host_paas_units = _calculate_host_units(int(host['passMemoryLimit']), monitoring_mode="PAAS")
                totalEnvPSHU = totalEnvPSHU + host_paas_units
                totalEnvHU = totalEnvHU + host_paas_units
            else:
                # Infra-only
                totalEnvIMHosts = totalEnvIMHosts + 1
                host_infra_only_units = _calculate_host_units(int(host['hostMemoryBytes']), monitoring_mode="INFRA_ONLY")
                totalEnvIMHU = totalEnvIMHU + host_infra_only_units
                totalEnvHU = totalEnvHU + host_infra_only_units
        state = ""
        if totalEnvHU > 0:
            if totalEnvIMHU == 0 and totalEnvPSHU == 0:
                state = "FullStack"
            elif totalEnvFSHU == 0 and totalEnvPSHU == 0:
                state = "Infrastructure"
            elif totalEnvIMHU == 0 and totalEnvFSHU == 0:
                state = "Application-only"
            else:
                state = "Mixed"
        else:
            state = "Unused"
        return totalEnvHU, totalEnvFSHU, totalEnvPSHU, totalEnvIMHU, totalEnvHosts, totalEnvFSHosts, totalEnvPSHosts, totalEnvIMHosts, state

    def get_environments(self):
        environmentsURL = f"{self.url}/api/cluster/v2/environments"
        params = {'pageSize': 1000}
        try:
            #getEnvironments = requests.get(environmentsURL, headers=self.auth_header, params=params, verify=self.verify_certs)
            getEnvironments = requests.get(environmentsURL, headers=self.auth_header, params=params)
            if getEnvironments.status_code == 401:
                error = getEnvironments.json()['error']['message']
                raise AuthException('Get Environments Error. Ensure your Cluster Token is correct, active and has the role ServiceProviderAPI. The message was - %s' % error)
        except requests.exceptions.ConnectTimeout as ex:
            raise ConfigException('Timeout on connecting with "%s"' % environmentsURL) from ex
        except requests.exceptions.RequestException as ex:
            raise ConfigException('Unable to connect to "%s"' % environmentsURL) from ex
        except json.JSONDecodeError as ex:
            raise ConfigException('Server response from %s is not json' % environmentsURL) from ex
        if "nextPageKey" in getEnvironments.json():
            environments = getEnvironments.json()['environments']
            nextPageKey = getEnvironments.json()['nextPageKey']
            requiredCalls = math.ceil(int(getEnvironments.json()['totalCount']) / int(getEnvironments.json()['pageSize']))
            i = 1
            while i < requiredCalls:
                if getEnvironments.json()['nextPageKey']:
                    nextPageKey = getEnvironments.json()['nextPageKey']
                params = {'nextPageKey': nextPageKey}
                try:
                    #getEnvironments = requests.get(environmentsURL, headers=self.auth_header, params=params, verify=self.verify_certs)
                    getEnvironments = requests.get(environmentsURL, headers=self.auth_header, params=params)
                    if getEnvironments.status_code == 401:
                        error = getEnvironments.json()['error']['message']
                        raise AuthException('Get Environments Error. Ensure your Cluster Token is correct, active and has the role ServiceProviderAPI. The message was - %s' % error)
                except requests.exceptions.ConnectTimeout as ex:
                    raise ConfigException('Timeout on connecting with "%s"' % environmentsURL) from ex
                except requests.exceptions.RequestException as ex:
                    raise ConfigException('Unable to connect to "%s"' % environmentsURL) from ex
                except json.JSONDecodeError as ex:
                    raise ConfigException('Server response from %s is not json' % environmentsURL) from ex
                pageDataEnvs = getEnvironments.json()['environments']
                for item in pageDataEnvs:
                    environments.append(item)
                i += 1
        else:
            environments = getEnvironments.json()['environments']
        # Convert to dict
        envDict = {}
        for e in environments:
            envDict[e['id']] = e
        return envDict

    def should_getLicenseExport(self):
        currentHour = int(datetime.datetime.now().hour)
        if currentHour != self.previousHour:
            #logger.info("Current is greater trigger DEM")
            self.previousHour = currentHour
            return True
        #logger.info("Current is the same as previous")
        return False
        #return True
    def get_LicenseExport(self):
        #logger.info("get_LicenseExport has been called")
        licenseExpURL = f"{self.url}/api/cluster/v2/license/consumption/hour"
        endTs = int(((round(time.time() * 1000))//3600000 * 3600000) - 7200000)
        startTs = endTs - 3600000
        params = {'startTs': startTs, 'endTs': endTs}
        #logger.info('The params are "%s"' % params)
        try:
            #getlicenseExp = requests.get(licenseExpURL, headers=self.auth_header, params=params, verify=self.verify_certs)
            getlicenseExp = requests.get(licenseExpURL, headers=self.auth_header, params=params)
            #logger.info('get_LicenseExport response code was "%s"' % getlicenseExp.status_code)
            if getlicenseExp.status_code == 401:
                error = getlicenseExp.json()['error']['message']
                raise AuthException('Get License Export Error. Ensure your Cluster Token is correct, active and has the role ServiceProviderAPI. The message was - %s' % error)
        except requests.exceptions.ConnectTimeout as ex:
            raise ConfigException('Timeout on connecting with "%s"' % licenseExpURL) from ex
        except requests.exceptions.RequestException as ex:
            raise ConfigException('Unable to connect to "%s"' % licenseExpURL) from ex
        except json.JSONDecodeError as ex:
            raise ConfigException('Server response from %s is not json' % licenseExpURL) from ex
        return getlicenseExp.json()['environmentBillingEntries']